// Script para Login e Registro funcionamento do Modal da página reglogm.php
