	<div class="container-fluid" style="clear:both;">
		<div class="row">
			<div class="col-md-12">
				<footer >
					<!-- Assinatura/Copyright e afins -->		
					<p style="text-align: center; ">© 2020 - Stream & Roll</p>
				</footer>
			</div>
		</div>
	</div>
</body>
</html>