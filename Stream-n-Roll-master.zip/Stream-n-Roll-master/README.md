# Stream'n Roll
Stream 'n Roll é um Trabalho de Graduação, cujo o objetivo é atender as necessidades da comunidade de RPG e Streamers
